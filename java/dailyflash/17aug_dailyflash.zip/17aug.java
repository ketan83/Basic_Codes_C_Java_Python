// PROGRAM NUMBER NAMES ARE WRITTEN AS CLASS NAMES ALONG WITH THEIR RESPECTIVE OUTPUTS

/*

// PROGRAM 1
class program1 {
	public static void main(String[] args) {

	int x =1  , y =2;

	if(x<y) 
		System.out.println(y+" is max among " +x+" & "+y+" \n");
}
}
O/p:
ketan@ketan-tuf-fx505dt:~/java/dailyflash$ java program1
2 is max among 1 & 2

ketan@ketan-tuf-fx505dt:~/java/dailyflash$



// PROGRAM 2
class program2 {
	public static void main(String[] args) {

		int x;
		System.out.println("Enter a number");
		x = -2;

		if(x==0)
		     System.out.println("Number is  "+x);
		else  
		     System.out.println("Number is  negative "+x);

	}
}
O/p:
ketan@ketan-tuf-fx505dt:~/java/dailyflash$ java program2
Enter a number
Number is  negative -2
ketan@ketan-tuf-fx505dt:~/java/dailyflash$
*/

/*
// PROGRAM 3
class program3 {
	public static void main(String[] args) {

	int x, i ,j;

		System.out.println("Enter a number");
		x =5;
	if(x%2==0)
		System.out.println(x+" is an even number ");
	else
		System.out.println(x+" is an odd number ");
}
}
o/p:
ketan@ketan-tuf-fx505dt:~/java/dailyflash$ java program3
Enter a number
5 is an odd number
ketan@ketan-tuf-fx505dt:~/java/dailyflash$



// PROGRAM 4

class program4 {
	public static void main(String[] args) {
	int i , j;

	for(i=1 ;i<=4 ;i++) {

		for(j=1 ;j<=4 ;j++) {

			System.out.print(" * ");
		}
		System.out.println("\n");
	}
}
}
O/p:
ketan@ketan-tuf-fx505dt:~/java/dailyflash$ java program4
 *  *  *  *

 *  *  *  *

 *  *  *  *

 *  *  *  *

ketan@ketan-tuf-fx505dt:~/java/dailyflash$
*/


/*
// PROGRAM 5
 

class program5 {
	public static void main(String[] args) {
        int i , j,x;
		System.out.println("Enter a number");
                x =55;

		if(x%11==0 && x%5==0)
			System.out.println(x + " is divisible by 5 & 11");
		else
			System.out.println(x + " is not divisible by 5 & 11");
			
}
}
O/P;
ketan@ketan-tuf-fx505dt:~/java/dailyflash$ java program5
Enter a number
55 is divisible by 5 & 11
ketan@ketan-tuf-fx505dt:~/java/dailyflash$
*/
